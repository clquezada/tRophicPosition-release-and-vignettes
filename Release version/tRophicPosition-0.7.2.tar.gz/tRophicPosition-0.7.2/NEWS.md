tRophicPosition v0.7.3 (Release date: 2017-10-12)
==============

* Minor details to fulfil CRAN checks

tRophicPosition v0.7.2 (Release date: 2017-10-12)
==============

* Fixed loadIsotopeData() when loading species without a community to iterate from.
* Added stable isotope data examples (Finnish Lakes and Roach)
* Improved credibilityIntervals(). Now it accepts legend position (for TP and alpha plots), a grouping variable (to plot groups with different colours), manual colours (scale_colour_manual) when using group_by, and labels for the x axis.

tRophicPosition v0.7.0 (Release date: 2017-06-11)
==============

First release version submitted to CRAN.

* List of capabilities
