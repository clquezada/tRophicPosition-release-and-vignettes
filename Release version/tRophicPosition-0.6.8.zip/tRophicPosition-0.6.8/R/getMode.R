#' Title
#'
#' @param df
#'
#' @return
#'
#' @examples
getMode <- function(df = NULL) {
  if (is.null(df)) stop()

}
