# tRophicPosition
A package to estimate trophic position using SIA.

If you are reading this, then you are on the GitHub site and/or have download the version from there. 

As of 14th of May 2017, we are releasing the version 0.6.8 of the package, the first release version. If find any error, please send them to trophicposition-support@googlegroups.com or raise an issue in the GitHub page.

If you are interested in join the tRophicPosition support group, do it at https://groups.google.com/d/forum/trophicposition-support

In the following weeks, we will be sending this package to CRAN, and will put here more news on how to cite properly this package.

If you want to make enquiries to the page, you can also send direct email to clquezada at harrodlab.net
