# To do list

- [ ] Set up a class IsoData for the isotope data
- [ ] Send a data frame to screenIsotopeData()
- [ ] Change deltaC to DELTAC (same to deltaN)
- [ ] Check the decimal points in the vignette
- [ ] Add the test for "=" in compareTwoDistributions()
- [ ] Check the messages of TEF()
- [ ] Modify generateTPData() and add to vignette
